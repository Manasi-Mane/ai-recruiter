const Profile = require('../models/Profile');

// GET my profile
exports.getProfile = async (req, res) => {
  try {
    let profile = await Profile.findOne({ user: req.user.id });
    if (!profile) return res.status(404).json({ message: 'Profile not found' });
    res.json(profile);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// CREATE or UPDATE profile
exports.saveProfile = async (req, res) => {
  try {
    const { summary, skills, experience, projects, education, completionPercent } = req.body;

    let profile = await Profile.findOne({ user: req.user.id });

    if (profile) {
      // Update existing profile
      profile.summary = summary || profile.summary;
      profile.skills = skills || profile.skills;
      profile.experience = experience || profile.experience;
      profile.projects = projects || profile.projects;
      profile.education = education || profile.education;
      profile.completionPercent = completionPercent || profile.completionPercent;
      profile.lastSaved = Date.now();
      await profile.save();
    } else {
      // Create new profile
      profile = new Profile({
        user: req.user.id,
        summary, skills, experience,
        projects, education, completionPercent
      });
      await profile.save();
    }

    res.json({ message: 'Profile saved!', profile });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
exports.aiParse = async (req, res) => {
  try {
    const { text, section } = req.body

    const prompts = {
      experience: `Extract structured experience data from this text. Return ONLY valid JSON like:
{"summary": "brief professional summary", "experience": [{"title": "Job Title", "company": "Company", "duration": "e.g. Jan 2022 - Dec 2023", "description": "what they did"}]}
Text: ${text}`,
      skills: `Extract a list of skills from this text. Return ONLY valid JSON like:
{"skills": ["React", "Node.js", "MongoDB"]}
Text: ${text}`,
      projects: `Extract project details from this text. Return ONLY valid JSON like:
{"projects": [{"name": "Project Name", "description": "what it does", "techStack": "React, Node.js", "link": ""}]}
Text: ${text}`,
      education: `Extract education details from this text. Return ONLY valid JSON like:
{"education": [{"degree": "B.Tech Computer Science", "institution": "University Name", "year": "2023"}]}
Text: ${text}`
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.CLAUDE_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompts[section] }]
      })
    })

    const data = await response.json()
    const rawText = data.content[0].text
    const cleaned = rawText.replace(/```json|```/g, '').trim()
    const parsed = JSON.parse(cleaned)

    res.json({ parsed })
  } catch (err) {
    res.status(500).json({ message: 'AI parsing failed', error: err.message })
  }
}
exports.aiParse = async (req, res) => {
  try {
    const { text, section } = req.body

    let parsed = {}

    if (section === 'experience') {
      parsed = {
        summary: `Experienced professional with background in ${text.slice(0, 60)}...`,
        experience: [{
          title: extractTitle(text),
          company: extractCompany(text),
          duration: extractDuration(text),
          description: text.slice(0, 200)
        }]
      }
    }

    if (section === 'skills') {
      const skillWords = text.match(/[A-Za-z#+.]+/g) || []
      parsed = {
        skills: [...new Set(skillWords.filter(w => w.length > 1))]
      }
    }

    if (section === 'projects') {
      parsed = {
        projects: [{
          name: text.split(' ').slice(0, 4).join(' '),
          description: text.slice(0, 200),
          techStack: extractSkills(text),
          link: ''
        }]
      }
    }

    if (section === 'education') {
      parsed = {
        education: [{
          degree: extractDegree(text),
          institution: extractInstitution(text),
          year: extractYear(text)
        }]
      }
    }

    res.json({ parsed })
  } catch (err) {
    res.status(500).json({ message: 'Parsing failed', error: err.message })
  }
}

// Helper functions
function extractTitle(text) {
  const titles = ['developer', 'engineer', 'designer', 'manager', 'analyst', 'intern', 'lead']
  const words = text.toLowerCase().split(' ')
  for (let w of words) {
    if (titles.some(t => w.includes(t))) return w.charAt(0).toUpperCase() + w.slice(1)
  }
  return 'Software Developer'
}

function extractCompany(text) {
  const match = text.match(/at\s+([A-Z][a-zA-Z\s]+?)(?:\s+for|\s+as|\.|,|$)/)
  return match ? match[1].trim() : 'Company Name'
}

function extractDuration(text) {
  const match = text.match(/(\d+)\s*year/)
  if (match) return `${match[1]} year(s)`
  const match2 = text.match(/(\d+)\s*month/)
  if (match2) return `${match2[1]} month(s)`
  return '1 year'
}

function extractSkills(text) {
  const tech = ['React', 'Node', 'MongoDB', 'Python', 'JavaScript', 'HTML', 'CSS', 'Express', 'SQL', 'Git', 'Java', 'Flutter']
  return tech.filter(t => text.toLowerCase().includes(t.toLowerCase())).join(', ') || 'JavaScript, React'
}

function extractDegree(text) {
  const degrees = ['B.Tech', 'M.Tech', 'BCA', 'MCA', 'B.Sc', 'MBA', 'B.E', 'Diploma']
  for (let d of degrees) {
    if (text.includes(d)) return d + ' ' + (text.split(d)[1]?.split(/[,.\n]/)[0]?.trim() || '')
  }
  return 'Bachelor of Technology'
}

function extractInstitution(text) {
  const match = text.match(/from\s+([A-Z][a-zA-Z\s]+?)(?:\s+in|\s+graduated|,|\.|$)/)
  return match ? match[1].trim() : 'University Name'
}

function extractYear(text) {
  const match = text.match(/20\d{2}/)
  return match ? match[0] : '2024'
}
// Profile = require('../models/Profile');

// GET my profile
exports.getProfile = async (req, res) => {
  try {
    let profile = await Profile.findOne({ user: req.user.id });
    if (!profile) return res.status(404).json({ message: 'Profile not found' });
    res.json(profile);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// CREATE or UPDATE profile
exports.saveProfile = async (req, res) => {
  try {
    const { summary, skills, experience, projects, education, completionPercent } = req.body;
    let profile = await Profile.findOne({ user: req.user.id });
    if (profile) {
      profile.summary = summary || profile.summary;
      profile.skills = skills || profile.skills;
      profile.experience = experience || profile.experience;
      profile.projects = projects || profile.projects;
      profile.education = education || profile.education;
      profile.completionPercent = completionPercent || profile.completionPercent;
      profile.lastSaved = Date.now();
      await profile.save();
    } else {
      profile = new Profile({
        user: req.user.id,
        summary, skills, experience,
        projects, education, completionPercent
      });
      await profile.save();
    }
    res.json({ message: 'Profile saved!', profile });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// AI PROCESS - structures user input
exports.aiProcess = async (req, res) => {
  try {
    const { message, step, profile } = req.body;

    let reply = '';
    let updatedProfile = { ...profile };

    if (step === 1) {
      updatedProfile.summary = `Motivated professional: ${message}`;
      reply = `Great to meet you! I've noted your introduction. 

🎯 Based on what you shared, I can see you're looking for exciting opportunities. Let's build your profile step by step!`;
    }

    else if (step === 2) {
      const expEntry = {
        title: 'Professional',
        company: 'Previous Company',
        duration: 'Recent',
        description: message
      };
      updatedProfile.experience = [...(profile.experience || []), expEntry];
      reply = `💼 Excellent! I've structured your experience:

✅ Role captured
✅ Description formatted  
✅ Added to your profile

Your experience section is looking great!`;
    }

    else if (step === 3) {
      const skillWords = message.split(/[,\s]+/).filter(s => s.length > 1);
      updatedProfile.skills = [...new Set([...(profile.skills || []), ...skillWords])];
      reply = `⚡ Perfect! I've extracted these skills from what you told me:

${updatedProfile.skills.map(s => `• ${s}`).join('\n')}

These will help recruiters find you easily!`;
    }

    else if (step === 4) {
      const projectEntry = {
        name: 'Project',
        description: message,
        techStack: 'Various',
        link: ''
      };
      updatedProfile.projects = [...(profile.projects || []), projectEntry];
      reply = `🚀 Amazing project! Here's what I captured:

✅ Project description saved
✅ Added to your portfolio

Recruiters love seeing real projects!`;
    }

    else if (step === 5) {
      const eduEntry = {
        degree: 'Degree',
        institution: message,
        year: new Date().getFullYear().toString()
      };
      updatedProfile.education = [...(profile.education || []), eduEntry];
      updatedProfile.summary = `${profile.summary || ''} Experienced professional with strong technical skills and hands-on project experience.`;
      reply = `🎓 Education added! 

🎉 **Your profile is now complete!**

Here's a summary of what we built:
✅ Introduction & Summary
✅ Work Experience  
✅ Skills (${updatedProfile.skills?.length || 0} skills)
✅ Projects
✅ Education

Click **"Preview Profile"** to see your complete profile!`;
    }

    res.json({ reply, profile: updatedProfile });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};